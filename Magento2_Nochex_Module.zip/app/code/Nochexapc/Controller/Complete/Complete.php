<?php
/**
 *
 * Copyright � 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Nochexapc\Nochex\Controller\Complete;

class Complete extends \Magento\Checkout\Controller\Onepage
{
    /**
     * Order success action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
       $order_id = $this->getRequest()->get('order_id');
		echo $order_id . "" . Test;
       
	   
    }
}
